<?php

class ConclusionView {
    
    public function __construct() {}
    
    public function show() {
        include __ROOT__ . "inc/Conclusion.php";
       
        
    }
}

