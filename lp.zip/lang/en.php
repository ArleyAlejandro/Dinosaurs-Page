<?php
$lang = [
    'nom' => 'Name',
    'ticker' => 'Ticker',
    'mercat' => 'Market',
    'ultima_coti' => 'Last Quotation',
    'divisa' => 'Currency',
    'variacio' => 'Variation',
    'variacio_percent' => 'Var %',
    'volum' => 'Volume',
    'minim' => 'Minimum',
    'maxim' => 'Maximum',
    'data' => 'Date',
    'hora' => 'Time',
    'select_language' => 'Select language',
    'save' => 'Save',
    'refresh' => 'Refresh',
];
