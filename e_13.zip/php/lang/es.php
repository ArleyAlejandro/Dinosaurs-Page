<?php
$lang = [
    'nom' => 'Nombre',
    'ticker' => 'Ticker',
    'mercat' => 'Mercado',
    'ultima_coti' => 'Última Cotización',
    'divisa' => 'Divisa',
    'variacio' => 'Variación',
    'variacio_percent' => 'Var %',
    'volum' => 'Volumen',
    'minim' => 'Mínimo',
    'maxim' => 'Máximo',
    'data' => 'Fecha',
    'hora' => 'Hora',
    'select_language' => 'Seleccionar idioma',
    'save' => 'Guardar',
    'refresh' => 'Refrescar',
];
