<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bolsa</title>
<link rel="stylesheet" href="../CSS/Web.css">
</head>

<?php
session_start();

// Manejo del idioma en la sesión y cookie
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['idioma'])) {
    $idioma = $_POST['idioma'];
    $_SESSION['idioma'] = $idioma; // Guardar el idioma en la sesión
    setcookie('idioma', $idioma, time() + (86400 * 30), "/"); // Establece una cookie de idioma que expira en 30 días
    header("Location: " . $_SERVER['PHP_SELF']); // Redireccionar para evitar reenvío de formulario
    exit();
}

// Verificar idioma en la sesión primero, luego en la cookie
$idioma = $_SESSION['idioma'] ?? $_COOKIE['idioma'] ?? 'es'; // Español como idioma predeterminado

if ($idioma === 'en') {
    include 'lang/en.php';
} elseif ($idioma === 'es') {
    include 'lang/es.php';
} else {
    include 'lang/es.php';
}

// Array con los elementos de la cabezera de la tabla.
$datosCabezera = [
    "nom", // Nom
    "ticker", // Ticker
    "mercat", // Mercado
    "ultima_coti", // Precio
    "divisa", // Divisa
    "variacio", // Dif
    "variacio_percent", // Dif %
    "volum", // Volum
    "minim", // Mínimo
    "maxim", // Máximo
    "data", // Fecha
    "hora" // Hora
];

// URL de la página desde la cual se va a extraer la información
$url = "https://www.inversis.com/inversiones/productos/cotizaciones-nacionales&pathMenu=3_1_0_0&esLH=N";

// Obtener el contenido HTML de la página web indicada
$texto = file_get_contents($url);

// Expresión regular para buscar todas las filas <tr> cuyo id comienza con "tr_" seguido de números
preg_match_all('/<tr id="tr_\d+".*?>.*?<\/tr>/s', $texto, $tr);

// Array para almacenar las celdas procesadas
$array = [];

// Recorrer cada una de las filas capturadas previamente
foreach ($tr[0] as $tr) {
    // Buscar todas las celdas <td> dentro de cada fila
    preg_match_all('/<td.*?>(.*?)<\/td>/s', $tr, $td);

    // Limpiar el contenido de las celdas
    $columnas_limpias = array_map(function ($columna) {
        // Remover etiquetas HTML, espacios en blanco y caracteres especiales
        $cleaned_column = strip_tags($columna);
        // Reemplazar &nbsp; y otros caracteres especiales
        $cleaned_column = str_replace('&nbsp;', ' ', $cleaned_column); // Eliminar &nbsp;
        return trim($cleaned_column);
    }, $td[1]); // Solo el contenido capturado dentro de las etiquetas <td>

    // Agregar las celdas ya limpias al array $array
    $array[] = $columnas_limpias;
}

// Llamar a la función para eliminar los elementos no deseados
eliminaElementoEnFila($array);

// Aplicar las claves del array de cabezera
$array = agregaIndice($array, $datosCabezera);

// echo '<pre>';
// var_dump($array);
// echo '</pre>';

/**
 * Función para eliminar los elementos no deseados del array, en este caso los del indice 3, 13 y 14.
 *
 * @param $array array
 *            al que se le quieren eliminar algunos elementos
 */
function eliminaElementoEnFila(&$array)
{
    // Recorrer cada fila del array
    foreach ($array as &$fila) {
        // Eliminar el elemento en la columna 3 (índice 3)
        unset($fila[3]);
        // Eliminar el elemento en la columna 13 (índice 12), si existe
        if (isset($fila[13])) {
            unset($fila[13]);
        }
        // Eliminar el elemento en la columna 14 (índice 13), si existe
        if (isset($fila[14])) {
            unset($fila[14]);
        }
    }
}

/**
 * A partir de un array con claves, agrega estas claves a otro array
 *
 * @param $array array
 *            al que le cambiaré las claves por defecto
 * @param $arrayIndices array
 *            con las claves que quiero utilizar
 * @return array[] retorna el array resultante
 */
function agregaIndice($array, $arrayIndices)
{
    $nuevoArray = []; // array auxiliar
    foreach ($array as $fila) {
        // Crea una array utilizando una array para claves y otra para sus valores
        $nuevoArray[] = array_combine($arrayIndices, $fila);
    }
    return $nuevoArray;
}

?>
   <body class="bolsa">
  
	<form method="POST" action="">
		<label for="idioma"><?php echo $lang['select_language']; ?></label> <select
			name="idioma" id="idioma">
			<option value="es" <?php if ($idioma === 'es') echo 'selected'; ?>>Español</option>
			<option value="en" <?php if ($idioma === 'en') echo 'selected'; ?>>English</option>
		</select>
		<button type="submit"><?php echo $lang['save']; ?></button>
		<button type="button" onclick="location.reload();"><?php echo $lang['refresh']; ?></button>
		 <a href="Home.php">Volver al Home</a>
	</form>
</body>

<?php


function pintaTabla($datosCabezera, $array, $lang)
{
    echo '<table>';
    echo '<thead><tr>';

    // Imprimir encabezados de la tabla
    foreach ($datosCabezera as $th) {
        echo '<th>' . htmlspecialchars($lang[$th]) . '</th>';
    }

    echo '</tr></thead>';
    echo '<tbody>';

    $ultimo_valor = null;

    foreach ($array as $subarray) {
        echo '<tr>'; // Añadir inicio de fila

        foreach ($subarray as $index => $celdas) {
            $colorFondo = ''; // Inicializar color de fondo por defecto
            $colorTexto = ''; // Inicializar color de texto por defecto

            // Limpiar el contenido de las celdas
            $limpieza_celdas = strip_tags($celdas); // Remover etiquetas HTML
            $valor = trim($limpieza_celdas); // Eliminar espacios en blanco

            // Comprobar si el índice es "ultima_coti"
            if ($index === 'ultima_coti') {

                // Verificar si hay un último valor para comparar
                if ($ultimo_valor !== null) {
                    // Asignar color de fondo según si ha aumentado o disminuido
                    $colorFondo = $valor > $ultimo_valor ? 'green' : 'red';
                }
                // Actualizar el último valor con el actual
                $ultimo_valor = $valor;
            }

            // Comprobar si el índice es "variacio" o "variacio_percent"
            if ($index === 'variacio' || $index === 'variacio_percent') {
                // Asignar color de texto
                $colorTexto = $valor < 0 ? 'red' : 'green';
            }

            // Imprimir la celda con el color de fondo o texto especificado
            echo '<td style="background-color:' . $colorFondo . '; color:' . $colorTexto . ';">' . htmlspecialchars($celdas) . '</td>';
        }
        echo '</tr>'; // Cerrar la fila después de las celdas
    }

    echo '</tbody>';
    echo '</table>';
}

pintaTabla($datosCabezera, $array, $lang);
?>
</html>

