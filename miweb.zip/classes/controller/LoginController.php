<?php

class LoginController
{

    public function __construct()
    {}

    public function show($params = null)
    {
        $vlogin = new LoginView();
        $vlogin->show();

    }

    public function form($params)
    {

        $email = $pass = '';

        // Objeto para hacer una consulta a la base de

        // Validar que el campo de email no esté vacío
        if (empty($params["email"])) {
            $errors['email'] = "El campo de email es obligatorio.";
        } elseif (! filter_var($params["email"], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = "El formato del email no es válido.";
        } else {
            $email = strtolower($params["email"]);
        }
        if (empty($params["contrasenya"])) {
            $errors['contrasenya'] = "El campo de contraseña es obligatorio.";
        } elseif (! validarContrasena($params["contrasenya"])) {
            $errors['contrasenya'] = "La contraseña debe tener al menos 8 caracteres, incluir mayúsculas, minúsculas, números y caracteres especiales.";
        } elseif(password_verify($params["contrasenya"], $params["contrasenya"])) {
            $errors['contrasenya'] = "La contraseña no es correcta.";
        } else {
            $pass = $params["contrasenya"];
        }

        $login = new LoginModel($email, $pass);

        if (! empty($errors)) {
            $login->errors = $errors;
        }else{
            $_SESSION['usuario_logueado'] = true;
            header('Location: index.php');
        }
        $vlogin = new LoginView();
        $vlogin->form($login);
    }
}
