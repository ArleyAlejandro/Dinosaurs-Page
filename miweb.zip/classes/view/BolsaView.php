<?php

class BolsaView {
    
    public function __construct() {}
    
    public function show() {
        include "../inc/bolsa.php";
    }
}