<?php

class CaracteristiquesView {
    
    public function __construct() {}
    
    public function show() {
        include __ROOT__ . "inc/Caracteristiques.php";
        
    }
}

