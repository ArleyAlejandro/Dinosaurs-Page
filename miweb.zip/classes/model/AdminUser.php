<?php

class AdminUser extends DBAbstractModel
{

    protected $id;
    public $name;
    public $lastName;
    public $userName;
    private $password;
    public $dni;
    public $phoneNumber;

    public function __construct()
    {
        parent::$db_user = 'usr_generic';
        parent::$db_pass = '2025@Thos';
    }

    public function set($data = [])
    {
        if (! empty($data)) {
            $this->query = "
                INSERT INTO usuarios (nombre, apellidos, nombre_de_usuario, email, contraseña, tipoID,
numero_identidad,fecha_nacimiento, sexo,direccion, provincia, codigo_postal, poblacion, numero_de_telefono, ruta_img)
                VALUES (
                  " . (empty($data['name']) ? "NULL" : "'{$data['name']}'") . ",
                " . (empty($data['lastName']) ? "NULL" : "'{$data['lastName']}'") . ",
                " . (empty($data['userName']) ? "NULL" : "'{$data['userName']}'") . ",
                " . (empty($data['email']) ? "NULL" : "'{$data['email']}'") . ",
                " . (empty($data['pass']) ? "NULL" : "'{$data['pass']}'") . ",
                " . (empty($data['typeID']) ? "NULL" : "'{$data['typeID']}'") . ",
                " . (empty($data['num_id']) ? "NULL" : "'{$data['num_id']}'") . ",
                " . (empty($data['birthdate']) ? "NULL" : "'{$data['birthdate']}'") . ",
                " . (empty($data['gender']) ? "NULL" : "'{$data['gender']}'") . ",
                " . (empty($data['address']) ? "NULL" : "'{$data['address']}'") . ",
                " . (empty($data['province']) ? "NULL" : "'{$data['province']}'") . ",
                " . (empty($data['postal']) ? "NULL" : "'{$data['postal']}'") . ",
                " . (empty($data['poblation']) ? "NULL" : "'{$data['poblation']}'") . ",
                " . (empty($data['phone']) ? "NULL" : "'{$data['phone']}'") . ",
                " . (empty($data['image']) ? "NULL" : "'{$data['image']}'") . "
                )
            ";
            $this->execute_single_query();
        }
    }

    public function edit($data = [])
    {
        foreach ($data as $clave => $valor) {
            $$clave      = $valor;
            $this->query = "UPDATE usuarios SET nombre='$name', apellidos='$lastName',
            nombre_de_usuario='$userName', contraseña='$password',
            dni='$dni',numero_de_telefono='$phoneNumber'
            WHERE nombre_de_usuario='$userName'";
        }
    }

    public function get()
    {

    }

    public function delete($userName = '')
    {

        $this->query = "
                DELETE FROM usuarios
                WHERE nombre_de_usuario = '$userName'
            ";
        $this->execute_single_query();

    }

}
