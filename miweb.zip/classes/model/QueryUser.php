<?php

class QueryUser extends DBAbstractModel {
    
    function __construct(){
        parent::$db_user = 'usr_consulta';
        parent::$db_pass = '2025@Thos';
    }
    
    public function get($user_email ='') 
    {
        $this->query = "SELECT * FROM usuarios WHERE email = '$user_email'";
        $this->get_results_from_query();
        
        if (count($this->rows) == 1) {
            foreach ($this->rows[0] as $prop => $value) {
                $this->$prop = $value;
            }
            return true;
        }
        
        return false;
    }
    
    protected function set()
    {}
    
    protected function edit()
    {}
    
    protected function delete()
    {}
}